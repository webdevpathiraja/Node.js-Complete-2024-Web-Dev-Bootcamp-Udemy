import generateName from "sillyname";
// var sillyName = generateName();

// console.log(`my name is ${sillyName}`);