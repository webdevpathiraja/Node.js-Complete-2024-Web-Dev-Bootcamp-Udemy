//var generateName = require('sillyname');

// import generateName from "sillyname";
// var sillyName = generateName();

// console.log(`my name is ${sillyName}`);


import superheroes from "superheroes";
const superName = superheroes.random();

console.log(`I'm ${superName}`);


